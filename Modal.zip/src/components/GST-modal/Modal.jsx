import React from 'react';
import './Modal.scss';
import RegulationsModal from './Regulations/regulations';
import Breakdown from './BreakDown/breakdown';

export default function Modal(){
    return(
        <div className='data-modal'>
            <h2 className='healine'>GST? No worries!</h2>
            <RegulationsModal/>
            <Breakdown/>
        </div>
    )
}